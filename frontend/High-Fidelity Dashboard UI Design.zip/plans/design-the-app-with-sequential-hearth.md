# Plan: AI Industry Monitoring Center Dashboard

## Context

Build a high-fidelity Russian-language B2B internal dashboard for PR/GR teams. Replaces a 3–4 hour manual daily routine of collecting, summarizing, and prioritizing industry news and legislative documents. Users: PR managers, GR/legal specialists, department heads.

**Aesthetic stance:** data-dense (Bloomberg/Linear/Attio density). Golos Text for Cyrillic (Google Fonts), true-white canvas, 13–14px base type, hairline dividers over card borders. Light theme primary with dark mode toggle.

---

## Files to Create / Modify

### `src/index.css`
- Add Google Fonts `@import` for Golos Text (wdth 400;500;600;700, cyrillic subset) at the very top
- Define CSS custom properties for light + dark theme tokens:
  - `--background`, `--foreground`, `--card`, `--muted`, `--border`, `--primary`, `--ring`, `--radius`
  - Priority colors: `--priority-critical` (red-600), `--priority-high` (orange-500), `--priority-medium` (blue-500), `--priority-low` (slate-400)
  - НПА lifecycle: `--status-draft` (slate-400), `--status-review` (blue-500), `--status-enacted` (emerald-500), `--status-archived` (slate-300)
- Dark mode via `.dark` class on `<html>`
- Set `font-family: 'Golos Text', sans-serif` as default
- Hide scrollbars by default, show on hover

### `src/App.tsx`
Shell component holding:
- Dark mode state (`useState<boolean>`)
- Active section state: `'feed' | 'npa' | 'digest' | 'sources'`
- Left sidebar (fixed, 200px): logo, nav items with icons, source status indicator
- Top bar: section title, date, dark mode toggle, notification bell
- Main content area: renders the active section component

### `src/components/Sidebar.tsx`
Nav links with active indicator, source health summary (N активных источников), user avatar at bottom.

### `src/components/NewsFeed.tsx`
Main news monitoring view. Layout: filter bar (source type toggles: СМИ / Telegram / Регуляторы, priority filter, date range) + scrollable item list.

Each news item row:
- Priority badge (dot + label): Критично / Высокий / Средний / Низкий — left-aligned, consistent color
- Source name + channel icon (16px)
- Headline (bold, 14px)
- AI summary (13px muted, 2 lines max, truncated)
- Edit-in-place button (pencil icon): clicking turns summary into a `<textarea>` with save/cancel. Placeholder: "Добавить заметку…", example pre-filled value: "Рассмотреть на совещании 12.09"
- Timestamp, thin right-side action buttons (bookmark, share)
- Hairline divider between items, no card borders

Include 8 realistic mock items covering: законопроект об ИИ, ЦБ регулирование финтех, ФАС проверка маркетплейсов, Минцифры стратегия, etc. At least 2 critical-priority items.

Loading skeleton: 5 placeholder rows with animated shimmer.

### `src/components/NpaTracker.tsx`
Legislative document tracker. Table layout (not cards):
- Columns: Статус · Документ · Орган · Дата публикации · Срок · Теги · Действия
- Status column: colored pill badge using lifecycle colors (Проект → На рассмотрении → Принят → Архив)
- Row hover: subtle bg highlight
- Inline "добавить заметку" action per row (edit-in-place pattern)
- Sort indicators on column headers
- 6 realistic НПА mock rows: Federal laws, CBR regulations, AI-related bills

### `src/components/DigestView.tsx`
Daily digest summary panel:
- AI-generated digest header (date + автор: ИИ-ассистент)
- Sections: Главное (3 critical items), Законодательство (2 items), Регуляторика (2 items)
- Each item: one-sentence summary with priority dot
- "Экспортировать" button (PDF/Email placeholder)
- Edit-in-place on the full digest text (user can correct AI hallucinations)

### `src/components/SourcesPanel.tsx`
Source management: list of connected sources (RSS feeds, Telegram channels, regulator sites) with status indicators (green/red dot), last fetch time, item count today. Simple table layout.

---

## Implementation Details

### Priority color system (consistent across all components)
```
Критично  →  bg-red-100 text-red-700 border-red-200     dot: bg-red-500
Высокий   →  bg-orange-100 text-orange-700              dot: bg-orange-500
Средний   →  bg-blue-100 text-blue-700                  dot: bg-blue-500
Низкий    →  (no badge, muted gray text)
```

### НПА lifecycle colors
```
Проект          → text-slate-500 bg-slate-100
На рассмотрении → text-blue-600 bg-blue-100
Принят          → text-emerald-700 bg-emerald-100
Архив           → text-slate-400 bg-slate-50 (faded)
```

### Edit-in-place pattern
- `editingId` state in parent or local component state
- When editing: replace `<p>` with `<textarea>` + Save/Cancel buttons
- Autofocus textarea on mount
- On save: update local mock data state

### Dark mode
- Toggle on topbar flips `document.documentElement.classList.toggle('dark')`
- All color tokens defined in both `:root` and `.dark` blocks in `index.css`

---

## Mock Data (Russian, realistic)

News items:
1. [Критично] Госдума приняла в первом чтении законопроект об ИИ-регулировании — ЦБ получает надзорные полномочия
2. [Критично] ЦБ РФ выпустил консультативный доклад о регулировании встроенных финансовых сервисов
3. [Высокий] Минцифры опубликовало обновлённую стратегию развития цифровой экономики до 2030 года
4. [Высокий] ФАС возбудила дело против крупного маркетплейса за злоупотребление доминирующим положением
5. [Средний] Роскомнадзор утвердил новые требования к локализации персональных данных иностранных сервисов
6. [Средний] Ассоциация банков России направила в ЦБ предложения по регулированию открытых API
7. [Низкий] Минэкономразвития запустило публичные консультации по законопроекту о цифровом рубле
8. [Низкий] Telegram-канал ФАС: плановые проверки ИТ-сектора перенесены на Q4 2026

НПА rows:
1. ФЗ об искусственном интеллекте (Проект) — Госдума — 15.08.2026 — срок: 01.12.2026
2. Положение ЦБ 821-П о финансовых экосистемах (На рассмотрении) — ЦБ РФ — 22.07.2026
3. Постановление Правительства о реестре ИИ-систем (Принят) — Правительство РФ — 10.06.2026
4. Приказ Минцифры о порядке сертификации ПО (Архив) — Минцифры — 14.03.2025
5. Законопроект о регулировании маркетплейсов (На рассмотрении) — Госдума — 02.09.2026
6. Указ о национальных стандартах кибербезопасности (Принят) — Президент РФ — 30.07.2026

---

## Verification

After implementation:
1. Check the preview renders without blank screen
2. Verify tab navigation switches between Feed / НПА / Дайджест / Источники
3. Verify dark mode toggle works
4. Verify edit-in-place on a news summary: click pencil → textarea appears → save updates text
5. Check priority color badges are visually distinct
6. Check НПА status pills use correct lifecycle colors

import { useState } from 'react'

const DEFAULT_DIGEST = `Сегодня зафиксированы два события критического приоритета, требующих немедленного внимания. Госдума приняла в первом чтении законопроект об ИИ-регулировании, наделяющий ЦБ надзорными полномочиями в области финансовых ИИ-систем. ЦБ РФ опубликовал консультативный доклад о встроенных финансовых сервисах — срок обсуждения до 20 октября.

В части законодательных изменений: Правительство утвердило постановление о реестре ИИ-систем в госуправлении, а Минцифры представило обновлённую стратегию цифровой экономики до 2030 года. Оба документа требуют анализа на предмет влияния на текущие проекты компании.

Регуляторный фон: Роскомнадзор расширил требования к локализации персональных данных, ФАС перенесла плановые проверки ИТ-сектора на Q4 2026.`

interface DigestSection {
  title: string
  items: { priority: 'critical' | 'high' | 'medium' | 'low'; text: string }[]
}

const SECTIONS: DigestSection[] = [
  {
    title: 'Главное',
    items: [
      { priority: 'critical', text: 'Госдума, первое чтение — законопроект об ИИ-регулировании, ЦБ получает надзорные полномочия' },
      { priority: 'critical', text: 'ЦБ РФ опубликовал доклад о embedded finance, срок комментариев — 20 октября' },
      { priority: 'high', text: 'ФАС возбудила дело против Wildberries за дискриминацию продавцов в ранжировании' },
    ],
  },
  {
    title: 'Законодательство',
    items: [
      { priority: 'high', text: 'Минцифры: стратегия цифровой экономики до 2030 — рост финансирования нацпроекта до 1,2 трлн руб.' },
      { priority: 'medium', text: 'МЭР: публичные консультации по законопроекту о цифровом рубле, срок — 30 сентября' },
    ],
  },
  {
    title: 'Регуляторика',
    items: [
      { priority: 'medium', text: 'РКН: новые требования к локализации данных, иностранные сервисы — аудит до 01.03.2027' },
      { priority: 'low', text: 'ФАС: перенос 14 плановых проверок ИТ-компаний на Q4 2026' },
    ],
  },
]

const DOT_COLOR: Record<string, string> = {
  critical: 'var(--priority-critical-dot)',
  high: 'var(--priority-high-dot)',
  medium: 'var(--priority-medium-dot)',
  low: 'var(--priority-low-dot)',
}

function ExportIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
      <path d="M6.5 1v8M3.5 6.5l3 3 3-3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M1.5 10.5h10" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  )
}

function PencilIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M8.5 1.5l2 2-7 7H1.5v-2l7-7z" stroke="currentColor" strokeWidth="1.1" fill="none" strokeLinejoin="round" />
    </svg>
  )
}

export default function DigestView() {
  const [editingDigest, setEditingDigest] = useState(false)
  const [digestText, setDigestText] = useState(DEFAULT_DIGEST)
  const [draftText, setDraftText] = useState(DEFAULT_DIGEST)

  const today = new Date().toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })

  return (
    <div className="flex h-full overflow-hidden">
      {/* Left: structured digest */}
      <div className="flex flex-col flex-1 overflow-y-auto border-r" style={{ borderColor: 'var(--border)' }}>
        {/* Header */}
        <div className="px-6 py-4 border-b" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="font-semibold text-[15px] mb-0.5" style={{ color: 'var(--foreground)' }}>
                Дайджест за {today}
              </div>
              <div className="text-[11px]" style={{ color: 'var(--muted-foreground)' }}>
                Сформирован ИИ-ассистентом · 16:00 · 8 материалов
              </div>
            </div>
            <button
              className="flex items-center gap-1.5 px-3 py-1.5 rounded border text-[12px] font-medium transition-colors"
              style={{ borderColor: 'var(--border)', color: 'var(--foreground)', background: 'var(--background)', cursor: 'pointer' }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'var(--muted)' }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'var(--background)' }}
            >
              <ExportIcon />
              Экспортировать
            </button>
          </div>
        </div>

        {/* Sections */}
        <div className="flex-1 px-6 py-4 space-y-6">
          {SECTIONS.map((sec) => (
            <div key={sec.title}>
              <div
                className="text-[11px] font-semibold uppercase tracking-wider mb-2"
                style={{ color: 'var(--muted-foreground)', letterSpacing: '0.08em' }}
              >
                {sec.title}
              </div>
              <div className="space-y-2">
                {sec.items.map((item, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <span
                      className="mt-1.5 inline-block rounded-full shrink-0"
                      style={{ width: 6, height: 6, background: DOT_COLOR[item.priority] }}
                    />
                    <span className="text-[13px] leading-relaxed" style={{ color: 'var(--foreground)' }}>
                      {item.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right: full text summary with edit-in-place */}
      <div className="flex flex-col" style={{ width: 380 }}>
        <div className="flex items-center justify-between px-5 py-3 border-b" style={{ borderColor: 'var(--border)' }}>
          <div className="text-[12px] font-semibold" style={{ color: 'var(--foreground)' }}>Текстовый резюме</div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: 'var(--muted)', color: 'var(--muted-foreground)' }}>
              ИИ-черновик
            </span>
            {!editingDigest && (
              <button
                onClick={() => { setDraftText(digestText); setEditingDigest(true) }}
                className="flex items-center gap-1 px-2 py-1 rounded text-[11px] transition-colors"
                style={{ background: 'var(--muted)', color: 'var(--muted-foreground)', cursor: 'pointer' }}
              >
                <PencilIcon />
                Редактировать
              </button>
            )}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {editingDigest ? (
            <div className="flex flex-col gap-3 h-full">
              <div className="text-[11px]" style={{ color: 'var(--muted-foreground)' }}>
                Исправьте неточности ИИ или добавьте контекст. Изменения сохранятся в системе.
              </div>
              <textarea
                autoFocus
                value={draftText}
                onChange={(e) => setDraftText(e.target.value)}
                className="flex-1 w-full rounded border px-3 py-2.5 text-[13px] resize-none outline-none leading-relaxed"
                style={{
                  borderColor: 'var(--primary)',
                  background: 'var(--background)',
                  color: 'var(--foreground)',
                  boxShadow: '0 0 0 2px var(--ring)',
                  fontFamily: 'inherit',
                  minHeight: 300,
                }}
              />
              <div className="flex gap-2">
                <button
                  onClick={() => { setDigestText(draftText); setEditingDigest(false) }}
                  className="flex-1 py-1.5 rounded text-[12px] font-medium"
                  style={{ background: 'var(--primary)', color: 'white', cursor: 'pointer' }}
                >
                  Сохранить изменения
                </button>
                <button
                  onClick={() => setEditingDigest(false)}
                  className="px-4 py-1.5 rounded text-[12px]"
                  style={{ background: 'var(--muted)', color: 'var(--muted-foreground)', cursor: 'pointer' }}
                >
                  Отмена
                </button>
              </div>
            </div>
          ) : (
            <div className="text-[13px] leading-relaxed whitespace-pre-line" style={{ color: 'var(--foreground)' }}>
              {digestText}
            </div>
          )}
        </div>

        {/* Footer stats */}
        <div className="px-5 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Критичных', value: '2', color: 'var(--priority-critical-dot)' },
              { label: 'НПА', value: '3', color: 'var(--priority-medium-dot)' },
              { label: 'Источников', value: '6', color: 'var(--muted-foreground)' },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="font-semibold text-[18px] leading-none mb-0.5" style={{ color: stat.color }}>
                  {stat.value}
                </div>
                <div className="text-[10px]" style={{ color: 'var(--muted-foreground)' }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

import { useState } from 'react'

type LifecycleStatus = 'draft' | 'review' | 'enacted' | 'archived'

interface NpaItem {
  id: string
  status: LifecycleStatus
  title: string
  organ: string
  published: string
  deadline: string | null
  tags: string[]
  note?: string
}

const MOCK_NPA: NpaItem[] = [
  {
    id: '1',
    status: 'draft',
    title: 'Федеральный закон «Об искусственном интеллекте»',
    organ: 'Госдума РФ',
    published: '15.08.2026',
    deadline: '01.12.2026',
    tags: ['ИИ', 'регулирование', 'надзор'],
    note: 'Ключевой документ — поставить на контроль',
  },
  {
    id: '2',
    status: 'review',
    title: 'Положение ЦБ 821-П о финансовых экосистемах и встроенных сервисах',
    organ: 'Банк России',
    published: '22.07.2026',
    deadline: '20.10.2026',
    tags: ['финтех', 'экосистемы', 'ЦБ'],
  },
  {
    id: '3',
    status: 'enacted',
    title: 'Постановление Правительства о реестре ИИ-систем, применяемых в госуправлении',
    organ: 'Правительство РФ',
    published: '10.06.2026',
    deadline: null,
    tags: ['ИИ', 'госуправление', 'реестр'],
  },
  {
    id: '4',
    status: 'review',
    title: 'Законопроект о регулировании деятельности маркетплейсов и агрегаторов',
    organ: 'Госдума РФ',
    published: '02.09.2026',
    deadline: '15.11.2026',
    tags: ['маркетплейсы', 'ФАС', 'конкуренция'],
  },
  {
    id: '5',
    status: 'enacted',
    title: 'Указ Президента о национальных стандартах кибербезопасности критической инфраструктуры',
    organ: 'Президент РФ',
    published: '30.07.2026',
    deadline: null,
    tags: ['кибербезопасность', 'КИИ'],
  },
  {
    id: '6',
    status: 'archived',
    title: 'Приказ Минцифры о порядке обязательной сертификации отечественного ПО',
    organ: 'Минцифры России',
    published: '14.03.2025',
    deadline: null,
    tags: ['ПО', 'сертификация', 'импортозамещение'],
  },
]

const STATUS_CONFIG: Record<LifecycleStatus, { label: string; bg: string; text: string }> = {
  draft: { label: 'Проект', bg: 'var(--status-draft-bg)', text: 'var(--status-draft-text)' },
  review: { label: 'На рассмотрении', bg: 'var(--status-review-bg)', text: 'var(--status-review-text)' },
  enacted: { label: 'Принят', bg: 'var(--status-enacted-bg)', text: 'var(--status-enacted-text)' },
  archived: { label: 'Архив', bg: 'var(--status-archived-bg)', text: 'var(--status-archived-text)' },
}

type SortKey = 'status' | 'published' | 'deadline'

function PencilIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 12 12" fill="none">
      <path d="M8.5 1.5l2 2-7 7H1.5v-2l7-7z" stroke="currentColor" strokeWidth="1.1" fill="none" strokeLinejoin="round" />
    </svg>
  )
}

function SortIcon({ active, dir }: { active: boolean; dir: 'asc' | 'desc' }) {
  return (
    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" style={{ opacity: active ? 1 : 0.3 }}>
      {dir === 'asc' ? (
        <path d="M2 7l3-4 3 4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      ) : (
        <path d="M2 3l3 4 3-4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      )}
    </svg>
  )
}

function NpaRow({ item, onUpdate }: { item: NpaItem; onUpdate: (id: string, note: string) => void }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(item.note ?? '')
  const cfg = STATUS_CONFIG[item.status]
  const isArchived = item.status === 'archived'

  const save = () => { onUpdate(item.id, draft); setEditing(false) }
  const cancel = () => { setDraft(item.note ?? ''); setEditing(false) }

  return (
    <tr
      className="group border-b transition-colors"
      style={{ borderColor: 'var(--border)', opacity: isArchived ? 0.6 : 1 }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'var(--muted)' }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent' }}
    >
      {/* Status */}
      <td className="px-4 py-2.5 whitespace-nowrap" style={{ width: 140 }}>
        <span
          className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium leading-none"
          style={{ background: cfg.bg, color: cfg.text }}
        >
          {cfg.label}
        </span>
      </td>

      {/* Document */}
      <td className="px-3 py-2.5">
        <div className="text-[13px] font-medium leading-snug mb-1" style={{ color: 'var(--foreground)' }}>
          {item.title}
        </div>
        <div className="flex flex-wrap gap-1">
          {item.tags.map((tag) => (
            <span
              key={tag}
              className="text-[10px] px-1.5 py-0.5 rounded leading-none"
              style={{ background: 'var(--border)', color: 'var(--muted-foreground)' }}
            >
              {tag}
            </span>
          ))}
        </div>
        {/* Note edit-in-place */}
        {!editing && item.note && (
          <div className="mt-1 text-[11px]" style={{ color: 'var(--muted-foreground)' }}>
            <span style={{ color: 'var(--priority-medium-text)' }}>📌</span> {item.note}
          </div>
        )}
        {editing && (
          <div className="mt-1.5">
            <textarea
              autoFocus
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Добавить заметку к документу..."
              className="w-full rounded border px-2 py-1.5 text-[12px] resize-none outline-none"
              style={{
                borderColor: 'var(--primary)',
                background: 'var(--background)',
                color: 'var(--foreground)',
                boxShadow: '0 0 0 2px var(--ring)',
                height: 60,
                fontFamily: 'inherit',
              }}
            />
            <div className="flex gap-1.5 mt-1">
              <button onClick={save} className="px-2 py-0.5 rounded text-[11px] font-medium" style={{ background: 'var(--primary)', color: 'white', cursor: 'pointer' }}>
                Сохранить
              </button>
              <button onClick={cancel} className="px-2 py-0.5 rounded text-[11px]" style={{ background: 'var(--muted)', color: 'var(--muted-foreground)', cursor: 'pointer' }}>
                Отмена
              </button>
            </div>
          </div>
        )}
      </td>

      {/* Organ */}
      <td className="px-3 py-2.5 whitespace-nowrap text-[12px]" style={{ color: 'var(--muted-foreground)', width: 160 }}>
        {item.organ}
      </td>

      {/* Published */}
      <td className="px-3 py-2.5 whitespace-nowrap text-[12px]" style={{ color: 'var(--muted-foreground)', width: 110, fontFamily: "'JetBrains Mono', monospace" }}>
        {item.published}
      </td>

      {/* Deadline */}
      <td className="px-3 py-2.5 whitespace-nowrap text-[12px]" style={{ width: 110 }}>
        {item.deadline ? (
          <span style={{ color: 'var(--priority-high-text)', fontFamily: "'JetBrains Mono', monospace" }}>{item.deadline}</span>
        ) : (
          <span style={{ color: 'var(--muted-foreground)' }}>—</span>
        )}
      </td>

      {/* Actions */}
      <td className="px-3 py-2.5 whitespace-nowrap" style={{ width: 60 }}>
        <button
          onClick={() => setEditing(!editing)}
          className="flex items-center justify-center rounded opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ width: 24, height: 24, background: 'var(--muted)', color: 'var(--muted-foreground)', cursor: 'pointer' }}
          title="Добавить заметку"
        >
          <PencilIcon />
        </button>
      </td>
    </tr>
  )
}

export default function NpaTracker() {
  const [items, setItems] = useState<NpaItem[]>(MOCK_NPA)
  const [sortKey, setSortKey] = useState<SortKey>('published')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')
  const [filterStatus, setFilterStatus] = useState<LifecycleStatus | 'all'>('all')

  const updateNote = (id: string, note: string) => {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, note } : it)))
  }

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortKey(key)
      setSortDir('desc')
    }
  }

  const ORDER: LifecycleStatus[] = ['draft', 'review', 'enacted', 'archived']

  const filtered = items
    .filter((it) => filterStatus === 'all' || it.status === filterStatus)
    .sort((a, b) => {
      let cmp = 0
      if (sortKey === 'status') cmp = ORDER.indexOf(a.status) - ORDER.indexOf(b.status)
      else if (sortKey === 'published') cmp = a.published.localeCompare(b.published)
      else if (sortKey === 'deadline') cmp = (a.deadline ?? '').localeCompare(b.deadline ?? '')
      return sortDir === 'asc' ? cmp : -cmp
    })

  const TH = ({ label, sortable, sk }: { label: string; sortable?: SortKey; sk?: SortKey }) => (
    <th
      className="text-left px-4 py-2 text-[11px] font-semibold uppercase tracking-wider border-b"
      style={{ borderColor: 'var(--border)', color: 'var(--muted-foreground)', letterSpacing: '0.06em', cursor: sortable ? 'pointer' : 'default', userSelect: 'none' }}
      onClick={() => sortable && handleSort(sortable)}
    >
      <span className="flex items-center gap-1">
        {label}
        {sortable && <SortIcon active={sortKey === sortable} dir={sortDir} />}
      </span>
    </th>
  )

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-3 px-5 py-2.5 border-b shrink-0" style={{ borderColor: 'var(--border)', background: 'var(--background)' }}>
        <span className="text-[11px]" style={{ color: 'var(--muted-foreground)' }}>Статус:</span>
        {(['all', 'draft', 'review', 'enacted', 'archived'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilterStatus(s)}
            className="px-2.5 py-0.5 rounded text-[11px] transition-colors"
            style={{
              background: filterStatus === s ? 'var(--foreground)' : 'transparent',
              color: filterStatus === s ? 'var(--background)' : 'var(--muted-foreground)',
              cursor: 'pointer',
            }}
          >
            {s === 'all' ? 'Все' : STATUS_CONFIG[s].label}
          </button>
        ))}
        <div className="ml-auto text-[11px]" style={{ color: 'var(--muted-foreground)' }}>{filtered.length} документов</div>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse" style={{ tableLayout: 'fixed' }}>
          <thead style={{ background: 'var(--background)', position: 'sticky', top: 0, zIndex: 1 }}>
            <tr>
              <TH label="Статус" sortable="status" />
              <TH label="Документ" />
              <TH label="Орган" />
              <TH label="Опубликован" sortable="published" />
              <TH label="Срок" sortable="deadline" />
              <TH label="" />
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-16 text-[13px]" style={{ color: 'var(--muted-foreground)' }}>
                  Документов не найдено
                </td>
              </tr>
            ) : (
              filtered.map((item) => <NpaRow key={item.id} item={item} onUpdate={updateNote} />)
            )}
          </tbody>
        </table>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 px-5 py-2 border-t shrink-0" style={{ borderColor: 'var(--border)', background: 'var(--background)' }}>
        <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: 'var(--muted-foreground)' }}>Жизненный цикл:</span>
        {(Object.entries(STATUS_CONFIG) as [LifecycleStatus, typeof STATUS_CONFIG[LifecycleStatus]][]).map(([key, cfg]) => (
          <span key={key} className="flex items-center gap-1.5 text-[11px]" style={{ color: 'var(--muted-foreground)' }}>
            <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-medium" style={{ background: cfg.bg, color: cfg.text }}>{cfg.label}</span>
          </span>
        ))}
        <span className="text-[11px] ml-1" style={{ color: 'var(--muted-foreground)' }}>→</span>
      </div>
    </div>
  )
}

import { useState, useEffect } from 'react'

type Priority = 'critical' | 'high' | 'medium' | 'low'
type SourceType = 'smi' | 'telegram' | 'regulator'

interface NewsItem {
  id: string
  priority: Priority
  source: string
  sourceType: SourceType
  headline: string
  summary: string
  time: string
  bookmarked: boolean
  note?: string
}

const MOCK_NEWS: NewsItem[] = [
  {
    id: '1',
    priority: 'critical',
    source: 'Коммерсантъ',
    sourceType: 'smi',
    headline: 'Госдума приняла в первом чтении законопроект об ИИ-регулировании — ЦБ получает надзорные полномочия',
    summary: 'Комитет по информационной политике одобрил поправки, наделяющие Банк России правом надзора за финансовыми ИИ-системами. Второе чтение запланировано на октябрь. Ключевые изменения касаются обязательной аккредитации ИИ-решений в банковской сфере.',
    time: '09:14',
    bookmarked: true,
    note: 'Рассмотреть на совещании 12.09',
  },
  {
    id: '2',
    priority: 'critical',
    source: 'ЦБ РФ',
    sourceType: 'regulator',
    headline: 'ЦБ РФ опубликовал консультативный доклад о регулировании встроенных финансовых сервисов и экосистем',
    summary: 'Банк России представил концепцию регулирования embedded finance: предлагается ввести реестр небанковских провайдеров, лицензионные требования к API-интеграциям и обязательный аудит алгоритмов скоринга. Публичное обсуждение — до 20 октября 2026.',
    time: '08:52',
    bookmarked: false,
  },
  {
    id: '3',
    priority: 'high',
    source: 'Минцифры',
    sourceType: 'regulator',
    headline: 'Минцифры опубликовало обновлённую стратегию цифровой экономики до 2030 года с расширенным разделом об ИИ',
    summary: 'Стратегия включает новые KPI: 40% госуслуг с ИИ-поддержкой к 2028 году, финансирование нацпроекта увеличено до 1,2 трлн руб. Отдельный раздел посвящён суверенным языковым моделям и требованиям к локализации данных.',
    time: '10:33',
    bookmarked: false,
  },
  {
    id: '4',
    priority: 'high',
    source: 'РБК',
    sourceType: 'smi',
    headline: 'ФАС возбудила дело против Wildberries за злоупотребление доминирующим положением при ранжировании товаров',
    summary: 'Антимонопольная служба установила признаки дискриминации продавцов, не подключившихся к рекламным инструментам маркетплейса. Предписание предполагает раскрытие алгоритмов ранжирования. Штраф может составить до 15% годового оборота.',
    time: '11:07',
    bookmarked: true,
  },
  {
    id: '5',
    priority: 'medium',
    source: 'Роскомнадзор',
    sourceType: 'regulator',
    headline: 'РКН утвердил новые требования к локализации персональных данных иностранных сервисов с российскими пользователями',
    summary: 'Приказ №487 расширяет перечень категорий данных, подлежащих хранению на серверах в РФ. Иностранные сервисы обязаны пройти аудит до 01.03.2027. Нарушителям грозит замедление трафика.',
    time: '12:15',
    bookmarked: false,
  },
  {
    id: '6',
    priority: 'medium',
    source: 'Ассоциация банков России',
    sourceType: 'smi',
    headline: 'АБР направила в ЦБ предложения по регулированию открытых API в финансовой сфере',
    summary: 'Ассоциация предлагает стандартизировать интерфейсы обмена данными между банками и финтех-компаниями по модели Open Banking. Документ включает требования к безопасности, ответственности за утечки и монетизации API.',
    time: '13:41',
    bookmarked: false,
  },
  {
    id: '7',
    priority: 'low',
    source: 'Минэкономразвития',
    sourceType: 'regulator',
    headline: 'МЭР запустило публичные консультации по законопроекту о цифровом рубле и смарт-контрактах',
    summary: 'Проект предполагает включение ЦФА-смарт-контрактов в гражданский оборот. Срок приёма предложений — 30 сентября. Планируется пилот с пятью банками в Q1 2027.',
    time: '14:22',
    bookmarked: false,
  },
  {
    id: '8',
    priority: 'low',
    source: 'ФАС России (TG)',
    sourceType: 'telegram',
    headline: 'Плановые проверки ИТ-компаний перенесены на Q4 2026 в связи с уточнением методологии',
    summary: 'ФАС сообщает о переносе 14 плановых проверок онлайн-платформ. Причина — доработка критериев оценки рыночной власти цифровых экосистем. Внеплановые проверки продолжатся в штатном режиме.',
    time: '15:08',
    bookmarked: false,
  },
]

const PRIORITY_CONFIG = {
  critical: { label: 'Критично', bg: 'var(--priority-critical-bg)', text: 'var(--priority-critical-text)', dot: 'var(--priority-critical-dot)' },
  high: { label: 'Высокий', bg: 'var(--priority-high-bg)', text: 'var(--priority-high-text)', dot: 'var(--priority-high-dot)' },
  medium: { label: 'Средний', bg: 'var(--priority-medium-bg)', text: 'var(--priority-medium-text)', dot: 'var(--priority-medium-dot)' },
  low: { label: 'Низкий', bg: 'transparent', text: 'var(--priority-low-text)', dot: 'var(--priority-low-dot)' },
}

const SOURCE_TYPE_LABELS: Record<SourceType, string> = {
  smi: 'СМИ',
  telegram: 'Telegram',
  regulator: 'Регуляторы',
}

function SkeletonRow() {
  return (
    <div className="flex gap-4 px-5 py-3.5 border-b" style={{ borderColor: 'var(--border)' }}>
      <div className="skeleton rounded" style={{ width: 64, height: 18, flexShrink: 0 }} />
      <div className="flex-1 min-w-0 flex flex-col gap-2">
        <div className="skeleton rounded" style={{ width: '75%', height: 14 }} />
        <div className="skeleton rounded" style={{ width: '90%', height: 13 }} />
        <div className="skeleton rounded" style={{ width: '55%', height: 13 }} />
      </div>
    </div>
  )
}

function PencilIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M8.5 1.5l2 2-7 7H1.5v-2l7-7z" stroke="currentColor" strokeWidth="1.1" fill="none" strokeLinejoin="round" />
    </svg>
  )
}

function BookmarkIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
      <path d="M2.5 1.5h8v10l-4-2.5-4 2.5V1.5z" stroke="currentColor" strokeWidth="1.1" fill={filled ? 'currentColor' : 'none'} strokeLinejoin="round" />
    </svg>
  )
}

function NewsRow({ item, onUpdate }: { item: NewsItem; onUpdate: (id: string, changes: Partial<NewsItem>) => void }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(item.note ?? '')
  const cfg = PRIORITY_CONFIG[item.priority]

  const saveNote = () => {
    onUpdate(item.id, { note: draft })
    setEditing(false)
  }

  const cancelEdit = () => {
    setDraft(item.note ?? '')
    setEditing(false)
  }

  return (
    <div
      className="group border-b transition-colors"
      style={{ borderColor: 'var(--border)' }}
      onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'var(--muted)' }}
      onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent' }}
    >
      <div className="flex gap-4 px-5 py-3">
        {/* Priority badge */}
        <div className="shrink-0 pt-0.5" style={{ width: 76 }}>
          {item.priority === 'low' ? (
            <div className="flex items-center gap-1">
              <span className="inline-block rounded-full shrink-0" style={{ width: 5, height: 5, background: cfg.dot }} />
              <span className="text-[11px]" style={{ color: cfg.text }}>Низкий</span>
            </div>
          ) : (
            <span
              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] font-medium leading-none"
              style={{ background: cfg.bg, color: cfg.text }}
            >
              <span className="inline-block rounded-full" style={{ width: 5, height: 5, background: cfg.dot, flexShrink: 0 }} />
              {cfg.label}
            </span>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-[11px] font-medium" style={{ color: 'var(--muted-foreground)' }}>{item.source}</span>
            <span
              className="text-[10px] px-1 py-0.5 rounded leading-none"
              style={{ background: 'var(--border)', color: 'var(--muted-foreground)' }}
            >
              {SOURCE_TYPE_LABELS[item.sourceType]}
            </span>
            <span className="text-[11px] ml-auto" style={{ color: 'var(--muted-foreground)' }}>{item.time}</span>
          </div>

          <div className="font-medium text-[13px] leading-snug mb-1" style={{ color: 'var(--foreground)' }}>
            {item.headline}
          </div>

          {!editing ? (
            <div className="text-[12px] leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
              {item.summary}
              {item.note && (
                <span
                  className="inline-flex items-center gap-1 ml-2 px-1.5 py-0.5 rounded text-[11px] leading-none"
                  style={{ background: 'var(--priority-medium-bg)', color: 'var(--priority-medium-text)', verticalAlign: 'middle' }}
                >
                  📌 {item.note}
                </span>
              )}
            </div>
          ) : (
            <div className="mt-1">
              <textarea
                autoFocus
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="Добавить заметку..."
                className="w-full rounded border px-2.5 py-2 text-[12px] resize-none outline-none"
                style={{
                  borderColor: 'var(--primary)',
                  background: 'var(--background)',
                  color: 'var(--foreground)',
                  boxShadow: '0 0 0 2px var(--ring)',
                  height: 70,
                  fontFamily: 'inherit',
                }}
              />
              <div className="flex gap-2 mt-1">
                <button
                  onClick={saveNote}
                  className="px-2.5 py-1 rounded text-[11px] font-medium transition-colors"
                  style={{ background: 'var(--primary)', color: 'white', cursor: 'pointer' }}
                >
                  Сохранить
                </button>
                <button
                  onClick={cancelEdit}
                  className="px-2.5 py-1 rounded text-[11px]"
                  style={{ background: 'var(--muted)', color: 'var(--muted-foreground)', cursor: 'pointer' }}
                >
                  Отмена
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-col items-center gap-1.5 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity pt-0.5">
          <button
            onClick={() => setEditing(!editing)}
            className="flex items-center justify-center rounded transition-colors"
            style={{ width: 24, height: 24, background: 'var(--muted)', color: 'var(--muted-foreground)', cursor: 'pointer' }}
            title="Редактировать заметку"
          >
            <PencilIcon />
          </button>
          <button
            onClick={() => onUpdate(item.id, { bookmarked: !item.bookmarked })}
            className="flex items-center justify-center rounded transition-colors"
            style={{
              width: 24, height: 24,
              background: item.bookmarked ? 'var(--priority-medium-bg)' : 'var(--muted)',
              color: item.bookmarked ? 'var(--priority-medium-text)' : 'var(--muted-foreground)',
              cursor: 'pointer',
            }}
          >
            <BookmarkIcon filled={item.bookmarked} />
          </button>
        </div>
      </div>
    </div>
  )
}

export default function NewsFeed() {
  const [loading, setLoading] = useState(true)
  const [items, setItems] = useState<NewsItem[]>(MOCK_NEWS)
  const [activeSource, setActiveSource] = useState<SourceType | 'all'>('all')
  const [activePriority, setActivePriority] = useState<Priority | 'all'>('all')

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1200)
    return () => clearTimeout(t)
  }, [])

  const updateItem = (id: string, changes: Partial<NewsItem>) => {
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...changes } : it)))
  }

  const filtered = items.filter((it) => {
    if (activeSource !== 'all' && it.sourceType !== activeSource) return false
    if (activePriority !== 'all' && it.priority !== activePriority) return false
    return true
  })

  const criticalCount = items.filter((it) => it.priority === 'critical').length

  return (
    <div className="flex flex-col h-full">
      {/* Filter bar */}
      <div
        className="flex items-center gap-4 px-5 py-2.5 border-b shrink-0"
        style={{ borderColor: 'var(--border)', background: 'var(--background)' }}
      >
        {/* Critical alert */}
        {criticalCount > 0 && (
          <div
            className="flex items-center gap-1.5 px-2.5 py-1 rounded text-[12px] font-medium"
            style={{ background: 'var(--priority-critical-bg)', color: 'var(--priority-critical-text)' }}
          >
            <span className="inline-block rounded-full" style={{ width: 6, height: 6, background: 'var(--priority-critical-dot)', flexShrink: 0 }} />
            {criticalCount} критичных
          </div>
        )}

        <div className="h-4 w-px" style={{ background: 'var(--border)' }} />

        {/* Source filter */}
        <div className="flex items-center gap-1">
          <span className="text-[11px] mr-1" style={{ color: 'var(--muted-foreground)' }}>Тип:</span>
          {(['all', 'smi', 'telegram', 'regulator'] as const).map((s) => (
            <button
              key={s}
              onClick={() => setActiveSource(s)}
              className="px-2 py-0.5 rounded text-[11px] transition-colors"
              style={{
                background: activeSource === s ? 'var(--foreground)' : 'transparent',
                color: activeSource === s ? 'var(--background)' : 'var(--muted-foreground)',
                cursor: 'pointer',
              }}
            >
              {s === 'all' ? 'Все' : SOURCE_TYPE_LABELS[s]}
            </button>
          ))}
        </div>

        <div className="h-4 w-px" style={{ background: 'var(--border)' }} />

        {/* Priority filter */}
        <div className="flex items-center gap-1">
          <span className="text-[11px] mr-1" style={{ color: 'var(--muted-foreground)' }}>Приоритет:</span>
          {(['all', 'critical', 'high', 'medium', 'low'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setActivePriority(p)}
              className="px-2 py-0.5 rounded text-[11px] transition-colors"
              style={{
                background: activePriority === p ? 'var(--foreground)' : 'transparent',
                color: activePriority === p ? 'var(--background)' : 'var(--muted-foreground)',
                cursor: 'pointer',
              }}
            >
              {p === 'all' ? 'Все' : PRIORITY_CONFIG[p].label}
            </button>
          ))}
        </div>

        <div className="ml-auto text-[11px]" style={{ color: 'var(--muted-foreground)' }}>
          {filtered.length} материалов
        </div>
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 gap-3">
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
              <circle cx="20" cy="20" r="18" stroke="var(--border)" strokeWidth="1.5" />
              <path d="M14 20h12M20 14v12" stroke="var(--border)" strokeWidth="1.5" strokeLinecap="round" transform="rotate(45 20 20)" />
            </svg>
            <div className="text-[13px]" style={{ color: 'var(--muted-foreground)' }}>Материалов не найдено</div>
            <button
              onClick={() => { setActiveSource('all'); setActivePriority('all') }}
              className="text-[12px] underline"
              style={{ color: 'var(--primary)', cursor: 'pointer', background: 'none', border: 'none' }}
            >
              Сбросить фильтры
            </button>
          </div>
        ) : (
          filtered.map((item) => <NewsRow key={item.id} item={item} onUpdate={updateItem} />)
        )}
      </div>
    </div>
  )
}

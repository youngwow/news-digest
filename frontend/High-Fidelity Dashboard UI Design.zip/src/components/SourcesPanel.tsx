import { useState } from 'react'

type SourceType = 'rss' | 'telegram' | 'web'
type SourceStatus = 'on' | 'off'

interface Source {
  id: string
  name: string
  url: string
  type: SourceType
  status: SourceStatus
  lastFetch: string
  todayCount: number
  totalCount: number
}

const MOCK_SOURCES: Source[] = [
  { id: '1', name: 'Коммерсантъ', url: 'rss.kommersant.ru/digest', type: 'rss', status: 'on', lastFetch: '5 мин. назад', todayCount: 12, totalCount: 3241 },
  { id: '2', name: 'РБК Технологии', url: 'rbc.ru/rss/technology', type: 'rss', status: 'on', lastFetch: '8 мин. назад', todayCount: 9, totalCount: 2187 },
  { id: '3', name: 'ЦБ РФ — Новости', url: 'cbr.ru/press/press_releases', type: 'web', status: 'on', lastFetch: '15 мин. назад', todayCount: 3, totalCount: 891 },
  { id: '4', name: 'Минцифры России', url: 'digital.gov.ru/press', type: 'web', status: 'on', lastFetch: '20 мин. назад', todayCount: 2, totalCount: 654 },
  { id: '5', name: 'ФАС России (TG)', url: 't.me/fas_russia', type: 'telegram', status: 'on', lastFetch: '3 мин. назад', todayCount: 7, totalCount: 1102 },
  { id: '6', name: 'Госдума РФ (TG)', url: 't.me/gosduma', type: 'telegram', status: 'on', lastFetch: '12 мин. назад', todayCount: 4, totalCount: 889 },
  { id: '7', name: 'Роскомнадзор', url: 'rkn.gov.ru/news', type: 'web', status: 'on', lastFetch: '42 мин. назад', todayCount: 1, totalCount: 447 },
  { id: '8', name: 'Ведомости', url: 'vedomosti.ru/rss', type: 'rss', status: 'on', lastFetch: '6 мин. назад', todayCount: 8, totalCount: 2903 },
  { id: '9', name: 'IT.Expert (TG)', url: 't.me/itexpert_ru', type: 'telegram', status: 'on', lastFetch: '2 мин. назад', todayCount: 14, totalCount: 3341 },
  { id: '10', name: 'Минэкономразвития', url: 'economy.gov.ru/press', type: 'web', status: 'off', lastFetch: '3 ч. назад', todayCount: 0, totalCount: 312 },
]

const TYPE_LABELS: Record<SourceType, string> = { rss: 'RSS', telegram: 'Telegram', web: 'Web' }

const STATUS_CONFIG: Record<SourceStatus, { dot: string; label: string; textColor: string }> = {
  on: { dot: '#22c55e', label: 'On', textColor: '#16a34a' },
  off: { dot: '#ef4444', label: 'Off', textColor: '#b91c1c' },
}

function RefreshIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M10 6A4 4 0 1 1 6 2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M6 1l2 1-2 1" stroke="currentColor" strokeWidth="1.1" strokeLinejoin="round" />
    </svg>
  )
}

function PlusIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <line x1="6" y1="2" x2="6" y2="10" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <line x1="2" y1="6" x2="10" y2="6" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  )
}

export default function SourcesPanel() {
  const [sources] = useState<Source[]>(MOCK_SOURCES)
  const [filterType, setFilterType] = useState<SourceType | 'all'>('all')
  const [filterStatus, setFilterStatus] = useState<SourceStatus | 'all'>('all')

  const filtered = sources.filter((s) => {
    if (filterType !== 'all' && s.type !== filterType) return false
    if (filterStatus !== 'all' && s.status !== filterStatus) return false
    return true
  })

  const stats = {
    on: sources.filter((s) => s.status === 'on').length,
    off: sources.filter((s) => s.status === 'off').length,
    todayTotal: sources.reduce((acc, s) => acc + s.todayCount, 0),
  }

  return (
    <div className="flex flex-col h-full">
      {/* Stats bar */}
      <div
        className="flex items-center gap-6 px-5 py-3 border-b shrink-0"
        style={{ borderColor: 'var(--border)', background: 'var(--background)' }}
      >
        <div className="flex items-center gap-1.5 text-[12px]" style={{ color: '#16a34a' }}>
          <span className="inline-block rounded-full" style={{ width: 7, height: 7, background: '#22c55e' }} />
          <span className="font-medium">{stats.on}</span>
          <span style={{ color: 'var(--muted-foreground)' }}>On</span>
        </div>
        {stats.off > 0 && (
          <div className="flex items-center gap-1.5 text-[12px]" style={{ color: '#b91c1c' }}>
            <span className="inline-block rounded-full" style={{ width: 7, height: 7, background: '#ef4444' }} />
            <span className="font-medium">{stats.off}</span>
            <span style={{ color: 'var(--muted-foreground)' }}>Off</span>
          </div>
        )}
        <div className="h-4 w-px ml-2" style={{ background: 'var(--border)' }} />
        <div className="text-[12px]" style={{ color: 'var(--muted-foreground)' }}>
          Сегодня собрано: <span className="font-semibold" style={{ color: 'var(--foreground)' }}>{stats.todayTotal}</span> материалов
        </div>

        <div className="ml-auto flex items-center gap-2">
          <button
            className="flex items-center gap-1.5 px-3 py-1.5 rounded border text-[12px] font-medium transition-colors"
            style={{ borderColor: 'var(--border)', color: 'var(--foreground)', background: 'var(--background)', cursor: 'pointer' }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'var(--muted)' }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'var(--background)' }}
          >
            <PlusIcon />
            Добавить источник
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 px-5 py-2 border-b shrink-0" style={{ borderColor: 'var(--border)' }}>
        <span className="text-[11px]" style={{ color: 'var(--muted-foreground)' }}>Тип:</span>
        {(['all', 'rss', 'telegram', 'web'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setFilterType(t)}
            className="px-2 py-0.5 rounded text-[11px] transition-colors"
            style={{
              background: filterType === t ? 'var(--foreground)' : 'transparent',
              color: filterType === t ? 'var(--background)' : 'var(--muted-foreground)',
              cursor: 'pointer',
            }}
          >
            {t === 'all' ? 'Все' : TYPE_LABELS[t]}
          </button>
        ))}
        <div className="h-3 w-px" style={{ background: 'var(--border)' }} />
        <span className="text-[11px]" style={{ color: 'var(--muted-foreground)' }}>Статус:</span>
        {(['all', 'on', 'off'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilterStatus(s)}
            className="px-2 py-0.5 rounded text-[11px] transition-colors"
            style={{
              background: filterStatus === s ? 'var(--foreground)' : 'transparent',
              color: filterStatus === s ? 'var(--background)' : 'var(--muted-foreground)',
              cursor: 'pointer',
            }}
          >
            {s === 'all' ? 'Все' : STATUS_CONFIG[s].label}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse" style={{ tableLayout: 'fixed' }}>
          <thead style={{ background: 'var(--background)', position: 'sticky', top: 0, zIndex: 1 }}>
            <tr>
              {[
                { label: 'Источник', w: undefined },
                { label: 'Тип', w: 90 },
                { label: 'Статус', w: 110 },
                { label: 'Последнее обновление', w: 150 },
                { label: 'Сегодня', w: 80 },
                { label: 'Всего', w: 80 },
                { label: '', w: 60 },
              ].map((col) => (
                <th
                  key={col.label}
                  className="text-left px-4 py-2 text-[11px] font-semibold uppercase tracking-wider border-b"
                  style={{ borderColor: 'var(--border)', color: 'var(--muted-foreground)', letterSpacing: '0.06em', width: col.w }}
                >
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((src) => {
              const sCfg = STATUS_CONFIG[src.status]
              return (
                <tr
                  key={src.id}
                  className="group border-b transition-colors"
                  style={{ borderColor: 'var(--border)' }}
                  onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = 'var(--muted)' }}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = 'transparent' }}
                >
                  <td className="px-4 py-2.5">
                    <div className="text-[13px] font-medium" style={{ color: 'var(--foreground)' }}>{src.name}</div>
                    <div className="text-[11px] mt-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'JetBrains Mono', monospace" }}>{src.url}</div>
                  </td>
                  <td className="px-4 py-2.5">
                    <span
                      className="text-[11px] px-1.5 py-0.5 rounded leading-none"
                      style={{ background: 'var(--border)', color: 'var(--muted-foreground)' }}
                    >
                      {TYPE_LABELS[src.type]}
                    </span>
                  </td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1.5">
                      <span className="inline-block rounded-full shrink-0" style={{ width: 6, height: 6, background: sCfg.dot }} />
                      <span className="text-[12px]" style={{ color: sCfg.textColor }}>{sCfg.label}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5 text-[12px]" style={{ color: src.status === 'off' ? sCfg.textColor : 'var(--muted-foreground)' }}>
                    {src.lastFetch}
                  </td>
                  <td className="px-4 py-2.5 text-[13px] font-semibold" style={{ color: src.todayCount > 0 ? 'var(--foreground)' : 'var(--muted-foreground)', fontFamily: "'JetBrains Mono', monospace" }}>
                    {src.todayCount}
                  </td>
                  <td className="px-4 py-2.5 text-[12px]" style={{ color: 'var(--muted-foreground)', fontFamily: "'JetBrains Mono', monospace" }}>
                    {src.totalCount.toLocaleString('ru')}
                  </td>
                  <td className="px-4 py-2.5">
                    <button
                      className="flex items-center justify-center rounded opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{ width: 26, height: 26, background: 'var(--muted)', color: 'var(--muted-foreground)', cursor: 'pointer' }}
                      title="Обновить источник"
                    >
                      <RefreshIcon />
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

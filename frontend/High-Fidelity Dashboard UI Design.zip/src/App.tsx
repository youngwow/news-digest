import { useState } from 'react'
import NewsFeed from './components/NewsFeed'
import NpaTracker from './components/NpaTracker'
import DigestView from './components/DigestView'
import SourcesPanel from './components/SourcesPanel'

type Section = 'feed' | 'npa' | 'digest' | 'sources'

const NAV: { id: Section; label: string; icon: string; badge?: number }[] = [
  { id: 'feed', label: 'Мониторинг', icon: 'feed', badge: 3 },
  { id: 'npa', label: 'НПА', icon: 'npa', badge: 2 },
  { id: 'digest', label: 'Дайджест', icon: 'digest' },
  { id: 'sources', label: 'Источники', icon: 'sources' },
]

const SECTION_TITLES: Record<Section, string> = {
  feed: 'Мониторинг',
  npa: 'Реестр НПА',
  digest: 'Ежедневный дайджест',
  sources: 'Источники данных',
}

function FeedIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <rect x="1" y="2" width="13" height="2" rx="1" fill="currentColor" opacity=".5" />
      <rect x="1" y="6.5" width="9" height="2" rx="1" fill="currentColor" />
      <rect x="1" y="11" width="11" height="2" rx="1" fill="currentColor" opacity=".5" />
    </svg>
  )
}
function NpaIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <path d="M3 1h7l3 3v10H3V1z" stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinejoin="round" />
      <path d="M10 1v3h3" stroke="currentColor" strokeWidth="1.2" fill="none" />
      <line x1="5" y1="6" x2="10" y2="6" stroke="currentColor" strokeWidth="1" opacity=".6" />
      <line x1="5" y1="8.5" x2="10" y2="8.5" stroke="currentColor" strokeWidth="1" opacity=".6" />
      <line x1="5" y1="11" x2="8" y2="11" stroke="currentColor" strokeWidth="1" opacity=".6" />
    </svg>
  )
}
function DigestIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <rect x="1" y="1" width="13" height="13" rx="2" stroke="currentColor" strokeWidth="1.2" fill="none" />
      <path d="M4 5h7M4 7.5h5M4 10h6" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity=".7" />
    </svg>
  )
}
function SourcesIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 15 15" fill="none">
      <circle cx="7.5" cy="7.5" r="2" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="7.5" cy="7.5" r="6" stroke="currentColor" strokeWidth="1.2" opacity=".4" />
      <line x1="7.5" y1="1.5" x2="7.5" y2="13.5" stroke="currentColor" strokeWidth="1" opacity=".3" />
      <path d="M2 5.5c1.5.5 3.5.8 5.5.8s4-.3 5.5-.8M2 9.5c1.5-.5 3.5-.8 5.5-.8s4 .3 5.5.8" stroke="currentColor" strokeWidth="1" opacity=".3" />
    </svg>
  )
}
function NavIcon({ id }: { id: string }) {
  if (id === 'feed') return <FeedIcon />
  if (id === 'npa') return <NpaIcon />
  if (id === 'digest') return <DigestIcon />
  return <SourcesIcon />
}

export default function App() {
  const [section, setSection] = useState<Section>('feed')
  const [dark, setDark] = useState(false)

  const toggleDark = () => {
    const next = !dark
    setDark(next)
    document.documentElement.classList.toggle('dark', next)
  }

  const today = new Date().toLocaleDateString('ru-RU', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  })

  return (
    <div className="flex h-full" style={{ background: 'var(--background)', color: 'var(--foreground)' }}>
      {/* Sidebar */}
      <aside
        className="flex flex-col shrink-0 border-r"
        style={{ width: 204, background: 'var(--sidebar)', borderColor: 'var(--border)' }}
      >
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-4 py-3.5 border-b" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-center justify-center rounded shrink-0" style={{ width: 26, height: 26, background: 'var(--primary)' }}>
            <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
              <circle cx="6.5" cy="6.5" r="3.5" stroke="white" strokeWidth="1.4" />
              <circle cx="6.5" cy="6.5" r="1.3" fill="white" />
            </svg>
          </div>
          <div>
            <div className="font-semibold text-[12px] leading-tight" style={{ color: 'var(--foreground)' }}>Мониторинг</div>
            <div className="text-[10px] leading-tight" style={{ color: 'var(--muted-foreground)' }}>ИИ-индустрия · ЦА</div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-2 px-2">
          <div className="text-[10px] font-semibold uppercase tracking-wider px-2 py-1.5 mb-0.5" style={{ color: 'var(--muted-foreground)', letterSpacing: '0.08em' }}>
            Разделы
          </div>
          {NAV.map((item) => {
            const active = section === item.id
            return (
              <button
                key={item.id}
                onClick={() => setSection(item.id)}
                className="flex items-center w-full gap-2 px-2 py-1.5 rounded text-left transition-all"
                style={{
                  background: active ? 'var(--primary)' : 'transparent',
                  color: active ? 'var(--primary-foreground)' : 'var(--sidebar-foreground)',
                  fontWeight: active ? 500 : 400,
                  fontSize: 13,
                  marginBottom: 1,
                }}
                onMouseEnter={(e) => { if (!active) (e.currentTarget as HTMLElement).style.background = 'var(--muted)' }}
                onMouseLeave={(e) => { if (!active) (e.currentTarget as HTMLElement).style.background = 'transparent' }}
              >
                <span style={{ opacity: active ? 1 : 0.6 }}><NavIcon id={item.icon} /></span>
                <span className="flex-1">{item.label}</span>
                {item.badge && (
                  <span
                    className="text-[10px] font-bold px-1.5 rounded-full leading-none py-0.5"
                    style={{
                      background: active ? 'rgba(255,255,255,0.28)' : 'var(--priority-critical-dot)',
                      color: 'white',
                    }}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            )
          })}
        </nav>

        {/* Source health */}
        <div className="px-4 py-2.5 border-t text-[11px]" style={{ borderColor: 'var(--border)', color: 'var(--muted-foreground)' }}>
          <div className="flex items-center gap-1.5 mb-0.5">
            <span className="inline-block rounded-full shrink-0" style={{ width: 6, height: 6, background: '#22c55e' }} />
            <span>24 источника активны</span>
          </div>
          <div style={{ color: 'var(--priority-low-text)', fontSize: 10 }}>Обновлено 2 мин. назад</div>
        </div>

        {/* User */}
        <div className="flex items-center gap-2 px-3 py-3 border-t" style={{ borderColor: 'var(--border)' }}>
          <div className="flex items-center justify-center rounded-full text-[11px] font-semibold shrink-0" style={{ width: 26, height: 26, background: '#dbeafe', color: '#1d4ed8' }}>
            АК
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[12px] font-medium truncate" style={{ color: 'var(--foreground)' }}>А. Кузнецова</div>
            <div className="text-[10px]" style={{ color: 'var(--muted-foreground)' }}>GR-аналитик</div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex flex-col flex-1 min-w-0">
        {/* Topbar */}
        <header
          className="flex items-center gap-3 px-5 border-b shrink-0"
          style={{ height: 48, borderColor: 'var(--border)', background: 'var(--background)' }}
        >
          <div className="flex-1 min-w-0">
            <span className="font-semibold text-[14px]" style={{ color: 'var(--foreground)' }}>{SECTION_TITLES[section]}</span>
            <span className="ml-3 text-[12px]" style={{ color: 'var(--muted-foreground)' }}>{today}</span>
          </div>

          {/* Search */}
          <div className="flex items-center gap-2 px-3 rounded border text-[12px]" style={{ height: 30, borderColor: 'var(--border)', background: 'var(--muted)', color: 'var(--muted-foreground)', width: 200 }}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <circle cx="5" cy="5" r="3.5" stroke="currentColor" strokeWidth="1.2" />
              <line x1="7.5" y1="7.5" x2="10.5" y2="10.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
            </svg>
            <span>Поиск...</span>
          </div>

          {/* Dark toggle */}
          <button
            onClick={toggleDark}
            className="flex items-center justify-center rounded border transition-colors"
            style={{ width: 30, height: 30, borderColor: 'var(--border)', background: 'transparent', color: 'var(--muted-foreground)', cursor: 'pointer' }}
            title={dark ? 'Светлая тема' : 'Тёмная тема'}
          >
            {dark ? (
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <circle cx="7" cy="7" r="2.5" stroke="currentColor" strokeWidth="1.2" />
                <line x1="7" y1="1" x2="7" y2="2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                <line x1="7" y1="11.5" x2="7" y2="13" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                <line x1="1" y1="7" x2="2.5" y2="7" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
                <line x1="11.5" y1="7" x2="13" y2="7" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path d="M12 8.5A5 5 0 0 1 5.5 2a5 5 0 1 0 6.5 6.5z" stroke="currentColor" strokeWidth="1.2" fill="none" />
              </svg>
            )}
          </button>

          {/* Bell */}
          <button
            className="relative flex items-center justify-center rounded border"
            style={{ width: 30, height: 30, borderColor: 'var(--border)', background: 'transparent', color: 'var(--muted-foreground)', cursor: 'pointer' }}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M7 1.5A3.5 3.5 0 0 0 3.5 5v3L2.5 9.5h9l-1-1.5V5A3.5 3.5 0 0 0 7 1.5z" stroke="currentColor" strokeWidth="1.2" fill="none" />
              <path d="M5.5 10.5a1.5 1.5 0 0 0 3 0" stroke="currentColor" strokeWidth="1.2" fill="none" />
            </svg>
            <span className="absolute rounded-full" style={{ width: 5, height: 5, background: 'var(--priority-critical-dot)', top: 6, right: 6 }} />
          </button>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-hidden">
          {section === 'feed' && <NewsFeed />}
          {section === 'npa' && <NpaTracker />}
          {section === 'digest' && <DigestView />}
          {section === 'sources' && <SourcesPanel />}
        </main>
      </div>
    </div>
  )
}
